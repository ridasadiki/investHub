<?php 
    class Util{
        //DB Variables
        static $DB_NAME = "harvest_hub";
        static $DB_USER = "root";
        static $DB_USER_PASS = "I6U(G}r#jy4Kn<\h";
        static $SERVER_NAME ="localhost";

        //About USSD Menu
        static $GO_BACK = "98";
        static $GO_TO_MAIN_MENU = "99";

        static $API_KEY ="a13b7fb905a910841598ef97ecc9de21a3060a159dce1e3789d35c9c9c69e706";
        static $API_USERNAME = "sandbox";

        static $SMS_SHORTCODE = "35277";
        static $COMPANY_NAME = "HH";


    }

?>
